<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241122;14231763">
	<META NAME="CHANGED" CONTENT="20241122;14285226">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		A:link { so-language: zxx }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>It would seem there are a
lot of reports</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5><A HREF="https://www.iicsa.org.uk/reports-recommendations/publications.html">https://www.iicsa.org.uk/reports-recommendations/publications.html</A></FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5><A HREF="https://www.churchofengland.org/sites/default/files/2024-11/independent-learning-lessons-review-john-smyth-qc-november-2024.pdf">https://www.churchofengland.org/sites/default/files/2024-11/independent-learning-lessons-review-john-smyth-qc-november-2024.pdf</A></FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>The first report came out
either in 2020 or 2022 I am not sure. But apparently one of the
findings was that institutions(including the Church) were putting
reputation above the care of children.)</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>