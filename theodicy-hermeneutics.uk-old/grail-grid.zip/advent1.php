<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241201;11392182">
	<META NAME="CHANGED" CONTENT="20241202;15474542">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>Advent and the Second
Coming</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>But
no true Christian has any right to count on dying. There is</FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>something
that is more certain than death. There are some who will never</FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>die.
Those who are alive and waiting for Christ when he comes, shall never</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>taste
of death.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=5>(Joseph
Seiss Apocalypse)</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=5>Advent
in the latin means coming or arrival. So of course this could mean
the coming or arrival of Christ in His inititial incarnation. Ie the
virgin birth. But then since the first incarnation has already
happened we are not really anticipating his first incarnation. If we
believe that Christ will indeed come again, then perhaps it is more
logical or even reasonable to look forward towards His Second
Coming?? Each has their own opinion. But then if we are talking about
a Biblical feast why do we not celebrate other Biblical feasts? </FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>