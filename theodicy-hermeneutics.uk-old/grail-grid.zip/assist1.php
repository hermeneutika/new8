<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241201;10124593">
	<META NAME="CHANGED" CONTENT="20241201;10585896">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
		A:link { so-language: zxx }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Assisted
Dying</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>In recent
weeks for me the news media have been full of the assisted dying
debate and vote in the UK House of Commons(HOC). The vote was in the
second reading of the private members bill. </FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><SPAN LANG="en">Kim
Leadbeater's Terminally Ill Adults (End of Life) Bill passed second
reading on 29 November by a wider than expected margin, </SPAN><SPAN LANG="en"><B>330&ndash;275</B></SPAN><SPAN LANG="en">.</SPAN>
</FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>(<A HREF="https://www.instituteforgovernment.org.uk/explainer/kim-leadbeaters-assisted-dying-bill">https://www.instituteforgovernment.org.uk/explainer/kim-leadbeaters-assisted-dying-bill</A>)</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>The bill
still needs a third reading before it goes to the House of
Lords(HOL). If we live in a democracy and it actually works, then 
surely if nothing else one should let ones MP know ones views on a
subject. </FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>So given
that this PMB is a free vote as a matter of conscience, then perhaps
it is valid to write to ones MP and lobby him/her on the subject. </FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>So why
choose Assisted Dying(AD). One argument is of course to alleviate
suffering. Another is the question of choice. Another perhaps is
economic though I hazard that few would take that position. Take a
look at the following link</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><A HREF="https://humanists.uk/2023/10/03/six-reasons-we-need-an-assisted-dying-law/">https://humanists.uk/2023/10/03/six-reasons-we-need-an-assisted-dying-law/</A></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>