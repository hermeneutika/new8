<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="AUTHOR" CONTENT="michael">
	<META NAME="CREATED" CONTENT="20230930;13060000">
	<META NAME="CHANGEDBY" CONTENT="michael falconer">
	<META NAME="CHANGED" CONTENT="20240506;15140000">
	<META NAME="AppVersion" CONTENT="16.0000">
	<META NAME="DocSecurity" CONTENT="0">
	<META NAME="HyperlinksChanged" CONTENT="false">
	<META NAME="LinksUpToDate" CONTENT="false">
	<META NAME="ScaleCrop" CONTENT="false">
	<META NAME="ShareDoc" CONTENT="false">
	<STYLE TYPE="text/css">
	<!--
		@page { size: 21.59cm 27.94cm; margin: 2.54cm }
		P { margin-bottom: 0.21cm; direction: ltr; color: #000000; font-size: 11pt; line-height: 115%; widows: 2; orphans: 2 }
		A:link { color: #0563c1; so-language: zxx }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" TEXT="#000000" LINK="#0563c1" DIR="LTR">
<?php include 'nav.php'; ?>
<P ALIGN=CENTER STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT FACE="Arial, serif"><FONT SIZE=4 STYLE="font-size: 16pt"><B>Michael
David Falconer </B></FONT></FONT>
</P>
<P ALIGN=CENTER STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT FACE="Arial, serif"><FONT SIZE=3>Flat 34 Mulberry Court, Moss
Lane, Macclesfield, Cheshire. SK11 7TP</FONT></FONT></P>
<P ALIGN=CENTER STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT FACE="Arial, serif"><FONT SIZE=3>Email </FONT></FONT><A HREF="mailto:hermeneutika@msn.com"><FONT COLOR="#000080"><FONT FACE="Arial, serif"><FONT SIZE=3><U>hermeneutika@msn.com</U></FONT></FONT></FONT></A><FONT FACE="Arial, serif"><FONT SIZE=3>
   Mobile 07982 416415 Land 01625-501793</FONT></FONT></P>
<P ALIGN=CENTER STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT FACE="Arial, serif"><FONT SIZE=3><U><B>Personal profile</B></U></FONT></FONT></P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT FACE="Arial, serif"><FONT SIZE=3>I have very good ICT skills,
with a recent open BSc with honours from the Open University.. I have
been given responsibility for ongoing projects which have been budget
and time critical, with a strong emphasis on customer service, and
customer re-orders due to good service given.I have a strong history
in production and quality control. I am available for an immediate
start. I have a up to date RTITB FLT counterbalance and Reach
licenses. I have completed manual handling and also Health and Safety
courses, with a strong commitment to safe working. I am an
experienced Warehouse Operative with now lapsed Counterbalance and
Reach FLT certificates.</FONT></FONT></P>
<P ALIGN=JUSTIFY STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
 
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><U><B>Key
Skills </B></U></FONT></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>Extensive experience of
	working within a  production team and warehouse working.</FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>Extremely good at handling
	materials and equipment adhering to strict manual handling
	techniques </FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>Attended training in ICT
	Skills ending with a open BSc with honours.</FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>A lifetime spent in
	industrial production</FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>Used hand held scanners for
	goods in/goods out </FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>Good organizational skills
	once I am up to too speed on the job. </FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>I have a valid taxi licence
	and have a good knowledge of transport routes in the uk</FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>I have in date RTITB reach
	and counterbalance flt licenses.</FONT></FONT></P>
</UL>
<P STYLE="margin-left: 1.27cm; margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>.</FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><U><B>WORK
EXPERIENCE </B></U></FONT></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">Various Temporary
contracts taken while I am looking for the correct job.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>March 2022 &ndash;
Oct 22</B></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif">
                                                    </FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>Company
Hays Agency for AZ</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>Job Title Line
operator </B></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">Job Description </FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">I was a grade 4
operator on a pharmaceutical packing line. This is a complex and
technical role involving the setting up of the line for packing
pharmaceutical products. However I am only a temp and the job may or
may not continue after the new year. I became ill, and had to leave,
but I seem a lot better now.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>June 2020 &ndash;
December 2021                                          Company:
Avantor</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000">                                               
                                   </FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>Job
Title : Lab supply operator</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>Job Description </B></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">This role involves
the supply of laboratory equipment to a series of Covid 19 test
laboratories. It involves being proactive to the labs. There was some
work involving access to -20 and -80 fridges.Plus the accurate
booking in of Covid 19 samples.Of course at all times wearing the
correct PPE and following procedures. I was working 11 hour shifts ,
on a four on,four off basis. </FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>Sept 2019 &ndash;
Jan 2020                                                 Company:
</B></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif">Manpower
at Garrett</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000">                                               
                                   </FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>Job
Title : Machine operator</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>Job Description </B></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">This role involves
the assembly of turbochargers. Using various testing equipment and
specialized tools. Also the role included keeping the OEE up to date
via a spreadsheet and also a intelligent scan gun. Also
troubleshooting skills were required when things did not go as
planned. Continuous improvement was actively encouraged using Kaizen
techniques.Finally I was involved in the packing of the finished
product in strict accordance with the customers specifications, and
the companies paperwork and computer systems. </FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">Garrett Motion UK had
received the Sword of Honour from the British Safety Council.One of 
the management teams key objectives was continuous transformation of
the company. Flexibility and the fast ability to adapt to change were
another. </FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>June 2019 &ndash;
August 2019                                               Company:
</B></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif">Redeem
via Agency</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000">                                               
                                   </FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>Job
Title : Mobile phone tester and repairs</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">This role involves
the sorting out of mobile phones into their various types. Testing
and fault finding checking  and attempting repairs to the various
phones. Mainly Apple machines. </FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>March 2019 &ndash;
 June 2019                                      Company </B></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif">:
Nestle via agency</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000">                                               
                                    </FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>Job
title  :</B></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif">
 flt operator</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">This role involves
driving a counterbalance fork lift truck(flt) . Collecting pallets of
the finished goods from the production line and placing them in the
warehouse racking. This also involves the use of an intelligent
scanner to scan the pallet and the racking location back to the
central warehousing database.This job involves working 12 hour shifts
on both days and nights and also some weekends. </FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>2 Oct 2017 &ndash;
 19 Nov 2018                                     Company </B></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif">:
Veolia Environmental Services</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000">                                               
                                    </FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><B>Job
title  :</B></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif">
 Waste Operative</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">I am involved in the
collection and processing of industrial waste from a large
manufacturing site. I am working on permanent earlies. I had to
operate FLT and also various compacting machines. My duties were many
and varied.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">26 Sept 2016 &ndash;
8 August 2017</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">Goods in Goods out</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">Tullis Russell via
Adecco Agency</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000">&bull;  <FONT FACE="Arial, serif">I am involved
in goods in/goods out preparing goods for transport.eg wrapping and
packing pallets and goods for transport and export.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000">&bull;  <FONT FACE="Arial, serif">The role also
involved the detailed filling in of the company paperwork and the use
of the companies computer systems as well as spreadsheets.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">15 August 2016  &ndash;
5 Sept 2016</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">Machine Operator</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">TMAC via the
Connections agency</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000">      &bull;  <FONT FACE="Arial, serif">I was
involved in goods in/goods out. Driving counterbalance fork lift
trucks. </FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">	 &bull;  I was also
involved in the operation of a computer controlled high pressure
water cutting machine.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000">       &bull; <FONT FACE="Arial, serif">The
position also involved general stock control, to ISO9001 standards.	</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000">      &bull;  <FONT FACE="Arial, serif">This
was a temporary position , they required a skilled worker to deal
with a temporary backlog of orders.</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">13 June 2016 &ndash;
15 July 2016 </FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">Driving and waste
management</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif">DoorCo via The Best
Connection agency</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif">I am involved in the safe and secure
	transportation of the client companies goods for either delivery or
	pick up.</FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif">When I am not involved in transport issues
	I am involved in ensuring that the waste management works smoothly.
	Clearing up all the waste produced by the CNC machines. Attempting
	to put into place proper waste management procedures. And thereby
	reducing the amount of waste going to landfill, thus reducing
	overall operating costs. </FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif">This was a purely temporary position
	providing holiday cover.</FONT></P>
</UL>
<P STYLE="margin-left: 1.27cm; margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT FACE="Arial, serif"><FONT SIZE=3><B>23 November 2015 &ndash; 25
April 2016</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT FACE="Arial, serif"><FONT SIZE=3><B>Quantity and Quality
Control and other task</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT FACE="Arial, serif"><FONT SIZE=3><B>Fastrak</B></FONT></FONT></P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>My main role here is again
	QC, but as this does not take up all my time I have to make myself
	available for other work which crops up. </FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>In this role I also use both
	reach and counterbalance FLT for loading and unloading of LGV, and
	location and delocating of stock from the warehouse multi tier
	racking. </FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>I am also responsible for all
	production and transport paperwork in the QC department. I have to 
	liase with the office to make sure our transport paperwork agrees so
	that we know that the current load has been despatched to the
	correct destination. </FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>The role is very similar to
	my previous role with Momentum. </FONT></FONT>
	</P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>6
June 2015 &ndash; 6 Nov 2015</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Quantity
and Quality Control</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Momentum
Instore</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>This
	was the biggest ever roll out in Europe and on the second biggest
	roll out globally. Over 38,000 locations had to be catered for.</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>At peak
	production we were moving over seven LGV&rsquo;s per day. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Each
	LGV had to be quantity and quality checked to ensure the correct
	range of components was going to the right location. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Also as
	the components were assembled and packed the packed boxes had to be
	checked for being the correct weight, and records kept. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>This
	was a two person job, but I was responsible for the oversight of QC
	operations. This also meant an ongoing relationship with all the
	agency staff as well as the other companies personnel.</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>I had
	to set up mobile computing facilities on site, which mainly involved
	just setting up email facility as there was no mobile signal, so we
	had to use Skype for phone calls. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>While
	all this was going on I successfully completed and passed my open
	BSc Honours(Third). </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>During
	this time I had ample time and opportunity to use both my
	counterbalance and reach licenses(RTITB registered on the NORS
	database and current) both without incident and not one dropped
	pallet. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>During
	the project I was involved obviously with my own company(Momentum
	Instore) and also with the manufacturing company Fastrak, who were
	responsible for the manufacturing and packing of the products. Also
	I to occasionally liase with the customers overall project manager. </FONT></FONT></FONT>
	</P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>7 Nov
2014 &ndash; 24 Dec 2014</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Pharmaceutical
Operator</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Sanofi
via Experis</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>As a
	new operator I am responsible for fitting into a new team and being
	able to pick up new procedures and make a positive contribution to
	the team and also the production targets. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>This
	involves becoming familiar with the processes of the company, and
	also all their documentation to ensure that all product is produced
	to the highest possible standards. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>This
	position also involved shift working.ie 6-2,2-10,10-6. A different
	shift every week. </FONT></FONT></FONT>
	</P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>July
2014 &ndash; 3 October 2014</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Inspector</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Apel
Ltd</B></FONT></FONT></FONT></P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Inspecting
	manufactured product to very tight tolerances, this was a major QC
	role. All components were checked to British Standards. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Dealing
	with various courier companies</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Despatch
	of goods to various sub process companies</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Enter
	works orders, purchase orders etc onto the SAGE 50 manufacturing
	software.</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Booking
	goods into the factory and also allocation of materials to the shop
	floor. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Goods
	warehousing and booking in/out procedures, to strict procedures,
	thus ensuring the correct materials were correctly located in stores
	and also allocated to the correct machine operation. This was the
	aerospace industry and we used many different ,but very similar
	materials for our components. The use of the wrong materials in a
	component could have potentially led to the failure of critical
	aerospace components. Hence compliance with procedures was ultra
	critical. </FONT></FONT></FONT>
	</P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>August
2012 &ndash; January 2014 	</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Production
Operative	</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Senior
Aerospace</B></FONT></FONT></FONT></P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>Producing air conditioning
	parts for the aerospace industry</FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>This work involves high
	degree of manual dexterity</FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>Developed a good ability to
	complete drawing</FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>Ability to work as part of a
	team.</FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT FACE="Arial, serif"><FONT SIZE=3>Ability to learn new skills
	was essential. </FONT></FONT>
	</P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Feb
2010 - June 2012 		</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Pharmaceutical
Packer	</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Astra
Zeneca</B></FONT></FONT></FONT></P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Working
	closely to coordinate and produce product</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>This
	position involved strong team work in a very close environment.</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Strong
	warehousing skills to a very high standard as pharmaceuticals were
	involved. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Involved
	with technical detail such as running machines and using  computers
	to operate systems</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Strong
	attention to detail on the paperwork, which was of a international
	nature. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Extremely
	diligent approach to the count of the product. Zero tolerance to
	even being incorrect by one. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>The job
	requires diligence as  medical quality drugs are packaged.</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Quality
	control procedures are at the highest standard.</FONT></FONT></FONT></P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>June
2008 to October 2009     	</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Waste
Operative			</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Veolia
Waste Management Services</B></FONT></FONT></FONT></P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Driving
	7.5 tonne vehicle, collecting specialised waste</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Driving
	a FLT to load and unload LGV with the compacted waste. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Bringing
	waste to waste processing plant where it would be compacted and
	cubed</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Worked
	well as part of a small team and able to use own initiative when
	required </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Good
	waste management is a critical part of modern industrial and
	corporate life, but sadly often greatly neglected, and adding
	massive costs to any industrial operation. In this case our waste
	management was of the highest quality on the Astra Zeneca site. </FONT></FONT></FONT>
	</P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>2007
to 2008      </B></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>
</FONT></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Granulator
Operator</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Shallcross
Limited</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Responsible
	for the operation of a plastic recycling machine</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>This
	involved looking after of the machine to ensure the correct
	materials are fed to it and that the product is correctly packaged
	and stored</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Operation
	of counterbalance FLT to load and unload LGV with either granulated
	product, or compacted product from the compaction section. </FONT></FONT></FONT>
	</P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>2005
to 2007 </B></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>
      </FONT></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Powder
Coater</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Everret
Charles Technology</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>ECT
	manufactured digital control gear for the manufacturing sector, for
	such companies as IBM Siemens etc. An American multinational company
	then in Macclesfield.My role included the cleaning of the finished
	kits with heated </FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>trichloroethylene
	in a special tank. &ldquo;Trike&rdquo; is higly toxic and dangerous
	material especially when heated to  a vapour. Strict safety
	procedures had to be followed or death would result.</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Also
	partially responsible for preparing certain items for inclusion in
	the kit manufacturing process</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Responsible
	for the powder coating of all the cleaned metal kits  manufactured.</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>This
	involves the tapping and deburring of various objects, prior to
	assembly </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Using a
	counterbalance FLT to load and unload vehicles.</FONT></FONT></FONT></P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>2005
to 2006 </B></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>
          </FONT></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Goods
In Inspector</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Bodycote</B></FONT></FONT></FONT></P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>As the
	Good In inspector I was responsible  for all incoming materials and
	their paperwork, and the booking onto the company database. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"> <FONT FACE="Arial, serif"><FONT SIZE=3>I also
	used a FLT to load and unload LGV.  </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>This
	was a higly responsible position. I was involved in incoming and
	outgoing QC for military standard aerospace components.    </FONT></FONT></FONT>
	</P>
</UL>
<P STYLE="margin-left: -1.25cm; margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>April
2005 to Nov 2005 </B></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>
 </FONT></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Goods
in, Warehousing</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Stormguard</B></FONT></FONT></FONT></P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000">   <FONT FACE="Arial, serif"><FONT SIZE=3>In
	this position I was responsible for the goods in department and the
	ongoing organisation of the department.</FONT></FONT></FONT></P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000">    <FONT FACE="Arial, serif"><FONT SIZE=3>I
	also used a FLT to load and unload LGV. </FONT></FONT></FONT>
	</P>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>I had
	to set up a computer database to record the location and quantities
	of our stock components , as I was also responsible for supplying
	the production line with raw materials for production. My database
	had to be correct as production availability of raw materials was
	essential. </FONT></FONT></FONT>
	</P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>1990-2004</B></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>		</FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Driver/Project
Manager/Quality Control</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Sutton
Castings</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Sutton
Castings was a U.K. leader in the design, production and delivery of
cast iron and aluminium castings for general engineering, the
automotive, train, oil rig and street architecture sectors.</FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Open
University</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Open
	Degree BSc Hon(Third) awarded by the Open University September 2015
	.</FONT></FONT></FONT></P>
</UL>
<P STYLE="margin-left: 1.27cm; margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Macclesfield
College of Further Education</B></FONT></FONT></FONT></P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>1 A
	Level, 5 O Levels</FONT></FONT></FONT></P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>.</FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>Poynton
High School</B></FONT></FONT></FONT></P>
<UL>
	<LI><P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
	<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>8 CSE
	and O Levels (A-C) including Maths and English  </FONT></FONT></FONT>
	</P>
</UL>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><U><B>Interests:</B></U></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3>Reading
computer related literature, philosophy and theology books, using my
computer, attending live music events and cycling a few times a week
to maintain fitness. Web design with database. Existentialist
philosophy. </FONT></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><U><B>References:</B></U></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<BR>
</P>
<P STYLE="margin-bottom: 0cm; line-height: 0.42cm; widows: 0; orphans: 0">
<FONT COLOR="#000000"><FONT FACE="Arial, serif"><FONT SIZE=3><B>References
available on request.</B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0.35cm; widows: 0; orphans: 0"><BR><BR>
</P>
</BODY>
</HTML>