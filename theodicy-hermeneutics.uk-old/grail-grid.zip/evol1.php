<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241107;13540267">
	<META NAME="CHANGED" CONTENT="20241107;14405926">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
		A:link { so-language: zxx }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Evolution
or blind chance</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>I first
became more fully aware of the Creation/Evolution debate when I was
working in a lab doing PCR (Polymerase Chain Reaction) tests. My open
Bsc Hons(Third) was mainly in IT. I knew nothing about biology etc.
But being a curious type I started looking into PCR and DNA. And
eventually found out that in most educational institutions the so
called theory of evolution was being taught as a full blown
scientifically proven law. </FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>We may as
well just play the Bloodhound Gang-The Soft Touch.....you and me baby
aint nothing but mammals, lets do it like they do on the discovery
channel!!!</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><A HREF="https://store.icr.org/The-Fossil-Record/productinfo/BFORE1/">https://store.icr.org/The-Fossil-Record/productinfo/BFORE1/</A></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><A HREF="https://store.creationmoments.com/purchase/the-young-earth-revised-and-expanded">https://store.creationmoments.com/purchase/the-young-earth-revised-and-expanded</A></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>