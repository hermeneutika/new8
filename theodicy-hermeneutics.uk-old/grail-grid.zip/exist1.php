<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241105;13374605">
	<META NAME="CHANGED" CONTENT="20241215;11102261">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Existentialism</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>As noted
elsewhere, my Christian Pentecostal friends may regard the use of
even the word ...philosophy as a sign of my infidelity.</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>For me
though as soon as one has spoken a non Biblical word or sentence one
is already in the realm of hermeneutics and philosophy. It is
unavoidable in my view. If ,as a work colleague said many years ago
about the game  of football, it is a game of opinions. I think this
applies in spades for philosophy and religion. And to put it perhaps
more politely still, opinions are like armpits,everyone has them. And
perhaps if someone has two Phd's in a subject, does that mean they
are given uncritical acceptance? Or if someone has the backing of the
heirarchy or is even thought to be &ldquo;annointed&rdquo; by the
Holy Spirit, again does that mean uncritical acceptance is given?</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>If
ultimately there is no authority at all....or really the only
authority can come from the back up of the evidence. Eg perhaps I am
on reasonably solid ground if I assert the speed of light in a vacuum
is approximately 300000kph. However I may not be on certain ground if
I say that God does not allow women to speak in the assemblies of the
saints. But of course some would affirm it , and others of course
would deny it. Each side of course giving the &ldquo;proof&rdquo; of
the authority of the written Holy Scriptures. Or in politics and
economics(the dismal science!), tarrifs for some are good for others
bad. Or assisted dying is good for others bad.  </FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>If however
there is a Holy God then things might change. Of course if there is
no God and therefore no moral absolutes, then I guess nothing
matters. Nothing makes a difference. But if there is a Creator
God.....</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>This is
the ultimate question. But not many seem to ask it. But I do.
Philosophy. And then of course Theology. These two disciplines were
once reckoned to be the King and Queen of the Sciences. But if we are
to go down the science route. What is a science? Surely it has
something to do with verification and empirical data? Who decides and
adjudicates? Whence cometh the Authority?</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Some
people turn to the Roman Church to settle the question of Authority.
Roman Catholicism has all the answers to all lifes problems. </FONT>
</P>
</BODY>
</HTML>