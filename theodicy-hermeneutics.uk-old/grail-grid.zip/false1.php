<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241026;13283142">
	<META NAME="CHANGED" CONTENT="20241026;13525374">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Deception</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>It was
either Sun Tzu or Von Cluauswitz who said all warfare is based on
deception. I Think it was Sun Tzu in the art of war. The Lord Jesus
also said</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=3 STYLE="font-size: 13pt"><B>4</B></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=3 STYLE="font-size: 13pt"><SPAN STYLE="font-weight: normal">
&para; </SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">
And Jesus answered and said unto them, Take heed that no man deceive
you.</SPAN></FONT></FONT></FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm; font-weight: normal"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm; font-weight: normal"><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt">The
Apostle Paul said </FONT></FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><FONT COLOR="#000000"><SUP><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">3</SPAN></FONT></FONT></SUP></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">
For such are false apostles, deceitful workers, transforming
themselves into apostles of Christ. </SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><SUP><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">14</SPAN></FONT></FONT></SUP></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">
And no wonder! For Satan himself transforms himself into an angel of
light. </SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><SUP><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">15</SPAN></FONT></FONT></SUP></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">
Therefore it is no great thing if his ministers also transform
themselves into ministers of righteousness, whose end will be
according to their works. 2 Corinthians 11:13-15</SPAN></FONT></FONT></FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">Then
of course there is the story of the old prophet...in 1 Kings 13 verse
18</SPAN></FONT></FONT></FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=3 STYLE="font-size: 13pt"><SPAN STYLE="font-weight: normal">18
</SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">
He said unto him, I </SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><I><SPAN STYLE="font-weight: normal">am</SPAN></I></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="font-weight: normal">
a prophet also as thou </SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><I><SPAN STYLE="font-weight: normal">art</SPAN></I></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="font-weight: normal">;
and an angel spake unto me by the word of the LORD, saying, Bring him
back with thee into thine house, that he may eat bread and drink
water. </SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><I><U><SPAN STYLE="font-weight: normal">But</SPAN></U></I></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><SPAN STYLE="font-weight: normal">
he lied unto him.</SPAN></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><U><SPAN STYLE="font-weight: normal">
</SPAN></U></FONT></FONT></FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm; text-decoration: none"><FONT SIZE=5><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">The
prophet of the Lord God Almighty paid a heavy price for listening to
and believing a fellow prophet. The Bible actually calls him a man of
God. Yet he was decieved by a fellow prophet and paid the ultimate
price,ie he was killed by a lion. He listened to the old prophet and
thus disobeyed the Lord and paid the price. Death!</SPAN></FONT></FONT></FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm; text-decoration: none"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm; text-decoration: none"><BR>
</P>
</BODY>
</HTML>