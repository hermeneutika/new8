<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241109;21192071">
	<META NAME="CHANGED" CONTENT="20241109;21271479">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=1 STYLE="font-size: 8pt"><B>We
live in dangerous times, and riches are uncertain</B></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=1 STYLE="font-size: 8pt"><B>things:
the way to make them safe, is to bestow</B></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=1 STYLE="font-size: 8pt"><B>them
upon the poor: Eccles. xi. 1, &quot; Cast thy</B></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=1 STYLE="font-size: 8pt"><B>bread
upon the waters: for thou shalt find it after</B></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=1 STYLE="font-size: 8pt"><B>many
days;&quot; if you keep it, you lose; if you cast it</B></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=1 STYLE="font-size: 8pt"><B>away,
you shall find it again.</B></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=1 STYLE="font-size: 8pt"><B>One
had this epitaph upon his tomb:</B></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=2><FONT SIZE=1 STYLE="font-size: 8pt"><I><B>Habeo
quod dedi, perdidi quud servavi: </B></I></FONT><FONT SIZE=1 STYLE="font-size: 8pt"><B>I
possess</B></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=1 STYLE="font-size: 8pt"><B>what
I gave; 1 have lost that which I kept.</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=1 STYLE="font-size: 8pt"><B>If
you would keep wine or meal, you put them</B></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm; font-weight: normal"><FONT SIZE=5><FONT FACE="Times New Roman, serif">The
above quote is taken from William Greenhill's commentary on the book
of the Prophet Ezekiel, on chapter 16:49</FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; font-weight: normal"><BR>
</P>
<P STYLE="margin-bottom: 0cm; font-weight: normal"><FONT FACE="Times New Roman, serif"><FONT SIZE=5><FONT COLOR="#000000"><B>Ezek
16:49</B></FONT><FONT COLOR="#000000">  Behold, this was the iniquity
of thy sister Sodom, pride, fulness of bread, and abundance of
idleness was in her and in her daughters, neither did she strengthen
the hand of the poor and needy.</FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm; font-weight: normal"><BR>
</P>
<P STYLE="margin-bottom: 0cm; font-weight: normal"><FONT FACE="Times New Roman, serif"><FONT SIZE=5><FONT COLOR="#000000">So
Greenhill is here commenting on this verse about strengthening the
hand of the poor. </FONT></FONT></FONT>
</P>
</BODY>
</HTML>