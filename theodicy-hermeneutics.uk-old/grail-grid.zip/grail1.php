<!-- index.html  -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content=
        "width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="grail.css" />
    <title>Holy Grail Layout</title>
</head>

<body>
    <div class="parent">
        <!--<header>
            Theodicy and the problems of evil and suffering.
        </header>-->
        <div class="left-sidebar">
            I am left sidebar

            <img src="palestine1.webp" width="150px" height="200px" alt="Palestinian Delusion cover image">
            <img src="myth1.jpeg" width="200px" height="200px" alt="mytho f mental illness image">
        </div>
        <main class="main">
            The Word of God is the total solution<br>
           Gen 2:17  But of the tree of the knowledge of good and evil, thou shalt not eat of it: for in the day that thou eatest thereof thou shalt surely die.<br>


           Gen 3:4  And the serpent said unto the woman, Ye shall not surely die:<br>

           17    And unto Adam he said, Because thou hast hearkened unto the voice of thy wife, and hast eaten of the tree, of which I commanded thee, saying, Thou shalt not eat of it: cursed [is] the ground for thy sake; in sorrow shalt thou eat [of] it all the days of thy life;<br>
18  Thorns also and thistles shall it bring forth to thee; and thou shalt eat the herb of the field;<br>
19  In the sweat of thy face shalt thou eat bread, till thou return unto the ground; for out of it wast thou taken: for dust thou [art], and unto dust shalt thou return.<br>
<br><br>
<iframe width="260" height="215" src="https://www.youtube.com/embed/_7LQxKoe9DU?si=vuwgbCKGYDIa5doL" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    <iframe width="260" height="215" src="https://www.youtube.com/embed/kipz75KvYvY?si=j1aocDqwp9jG-5L5" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </main>
        <!--<div class="right-sidebar">
            I am right sidebar and
            I am having more text<br>
            <img src="bible.jpg" width="200px" height="200px" alt="bible photo">
            <img src="interp1.jpg" width="200px" height="200px" alt="interpretation of the NT">
        </div>-->
        <footer>I am footer

        <a href="mailto:theodicy@michael.myzen.co.uk">Send email</a>

        </footer>

    </div>
</body>

</html>
