<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241103;10370356">
	<META NAME="CHANGED" CONTENT="20241103;11233839">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Divine
Healing or miraculous healing</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Seems like
this is a very controversial point. Of course,so far all people die.
But Joseph Seiss in his exposition of the Apocalypse of Jesus Christ
on page 166</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>I
have several times explained, that the first thing to be looked for
in the</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>great
and marvellous transactions embraced in the consummation of all</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>things,
is the mysterious coming of the Lord Jesus to take those that wait</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>and
watch for him, with such of the dead as have fallen asleep in the
same</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>attitude.
Good people are apt to be thinking of dying, and of being ready</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>for
death. But no true Christian has any right to count on dying. There
is</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>something
that is more certain than death. There are some who will never</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>die.
Those who are alive and waiting for Christ when he comes, shall never</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=2><FONT SIZE=3>taste
of death. They shall be &ldquo;</FONT><FONT SIZE=3><I>taken</I></FONT><FONT SIZE=3>&rdquo;
as Enoch was taken, as Elijah was</FONT></FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>taken,
as Romanists allege that the Virgin Mary was taken, and as some</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>say
the Apostle John was taken. The words of Paul upon this point are too</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>plain
to be misunderstood. He says, &ldquo;The Lord himself shall descend
from</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=3><FONT FACE="Times New Roman, serif">heaven
with a shout,&hellip; and we which are alive and remain shall be
caught</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><FONT FACE="Times New Roman, serif">But
generally all people will die unless Christ comes first. And one of
the arguments against healing is that all will die sometime. Which of
course noone will really deny. </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><FONT FACE="Times New Roman, serif">But
if God is really God, ie a all powerful supernatural being for Whom
nothing is impossible, then healing a disease is pretty small
potatoes. Surely if God is God. We could of course argue against His
willingness.....He may not be willing......And if we demand full
sovereignty then surely God does too? He will not be pressured into
something any more that we will. But then some preachers argue that
it is fatal to pray &ldquo;if it be Thy will.&rdquo;.....and then of
course some preachers would say that to &ldquo;ask&rdquo; is actually
to &ldquo;require&rdquo; or even &ldquo;demand&rdquo;. </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><FONT FACE="Times New Roman, serif">But
if &ldquo;according to ones faith it will be done to you&rdquo;......then
the onus lies with us......But others are outraged by this, how could
God withold healing because ones faith was not strong enough. And so
the arguments continue. The differences of opinions. So what is the
Truth of the matter? </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=3 STYLE="font-size: 13pt"><B>1Ki
17:24</B></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">
 And the woman said to Elijah, Now by this I know that thou </SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><I><SPAN STYLE="font-weight: normal">art</SPAN></I></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="font-weight: normal">
a man of God, </SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><I><SPAN STYLE="font-weight: normal">and</SPAN></I></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="font-weight: normal">
that the </SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>word</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
of the LORD in </SPAN></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>thy</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
mouth </SPAN></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><I><U><B>is</B></U></I></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
</SPAN></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>truth</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">.</SPAN></SPAN></SPAN></FONT></FONT></FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=3 STYLE="font-size: 13pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><B>Joh
17:17</B></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
 Sanctify them through </SPAN></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>thy</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
</SPAN></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>truth</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">:
</SPAN></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>thy</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
</SPAN></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>word</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
</SPAN></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>is</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
</SPAN></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>truth</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">.</SPAN></SPAN></SPAN></FONT></FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>I remember
reading decades ago in the Carlos Casteneda books decades ago.....</FONT></P>
</BODY>
</HTML>