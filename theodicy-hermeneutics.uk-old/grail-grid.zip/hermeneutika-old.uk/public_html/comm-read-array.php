<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
<title>Page title</title>
 <link href="menu.css" rel="stylesheet" type="text/css" />
 <link href="site.css" rel="stylesheet" type="text/css" />
</head>
<body>

<?php include ("menu.php"); ?>
<form action="comm-read-display-old3.php" method="post">
Author:<input type="text" name="author"><br>
Book : <input type="text" name="book"><br>
Chapt: <input type="text" name="chapt"><br>
Verse: <input type="text" name="verse"><br>

<input type="submit">
</form>

</body>
</html>
