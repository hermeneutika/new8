<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
<title>Page title</title>
<link href="site.css" rel="stylesheet" type="text/css" />
<?php include ("menu.php"); ?>
<?php include ("link.php"); ?>
</head>
<body>

<?php
////
//echo "rest";
//$author=$_POST["author"];
//$book=$_POST["book"];
//$chapt= $_POST["chapt"];
//$verse= $_POST["verse"];
//$query="select * from bible where n like '$book%' and chapt='$chapt' and verse='$verse';";
//$query .="select * from michael where n like '$book%' and chapt='$chapt' verse='$verse'";
echo "test";
//if ( mysqli_multi_query($link, $query))

//$result2=mysqli_query($link2,$query2);
//$result=  mysqli_query($link, $query);
//{
//do {
//if ($result=mysqli_store_result($link))
//{

//while($row = mysqli_fetch_row($result))
/{
//printf("%s\n",$row[0]);
///}
//mysqli_free_result($result);
//}
//if (mysqli_more_results($link)
//{
//printf ("----------------------\n");
//}
//}
//while  (mysqli_next_result($link));
//}
//mysqli_close($link);
//$row2=mysqli_fetch_array($result2,MYSQLI_BOTH);
//printf ("%s (%s)\n", $row[0], $row["text"]);
//echo "Book ".$row["n"]." Chapt ".$row["chapt"]." verse ".$row["verse"];
//echo " ";
//echo "<br>";
//echo $row["text"];
//echo "<br>";
//echo "<br>";
// commentary by Michael
//echo "<br>";
//echo "commentary by Michael";
//echo $row2["text"];
?>






</body>
</html>
