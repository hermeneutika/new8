<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
<title>Page title</title>
<link href="site.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php include ("menu.php"); ?>



<p>This site is dedicated to the Supreme Being and Architect of the Cosmos. </p>
<p>The entire Christian Godhead</p>



</body>
</html>
