<!DOCTYPE html>
<html>
<head>
<style>
</style>
<link href="menu.css" rel="stylesheet" type="text/css" />
</head>
<body class="covid1">
<?php include ("menu-main.php"); ?>
<h1>Covid 19</h1>
<h1>Pure eternal existentialism.v1</h1>

<br />
<br />
<a style="color:white" href="https://www.thetimes.co.uk/article/china-the-who-and-the-power-grab-that-fuelled-a-pandemic-3mt05m06n">The Times report into China</a>

</body>
</html>

