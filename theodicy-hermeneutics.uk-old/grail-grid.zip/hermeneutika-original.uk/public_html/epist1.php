<!DOCTYPE html>
<html>
<head>
<style>
</style>
<link href="menu.css" rel="stylesheet" type="text/css" />
</head>
<body class="epist1">
<?php include ("menu-main.php"); ?>
<h1>Epistemology</h1>
<h1>The pursuit of knowldge</h1>

<p> Epistemology,the definition...<a  style="color:white;" href="https://plato.stanford.edu/entries/epistemology/">is here</a></p>
<p> for those who like such things. I feel i have to deal with the criticism of people who have pursued the rational path to knowledge</p>
<p> The criticism is that people with paper qualifications have no "gumption" or "nouse" or worse "common sense"</p>
<p> After all it is "common sense" that the sun goes round the earth. See how the sun moves across the sky. Its "common sense"</p>
<p> I happen to work in a PCR lab. If it is true, as Max Weber said, "that fundamental doubt is the father of knowledge"</P>
<p> The inventor of PCR Kary Mullis, was qualified. He also recieved the Noble prize for peace. He solved a lot of problems. </p>
<p> PCR today has if nothing else, created a lot of employment. And also perhaps helped immensely in the fight against covid . I wont capitalise covid</p>
<p> If one accepts the governments and medical authorities narrative that we are in the middle of a pandemic</p>




</body>
</html>

