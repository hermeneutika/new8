<!doctype html>
<html lang="en">
<head>

  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CSS Menu testing</title>

  
  <style>
    
  </style>
  
  <link rel="stylesheet" href="menu.css" />
  <link rel="stylesheet" href="header.css" />
  <link rel="stylesheet" href="site.css" />
</head>
<body>
<?php

include("counter.php");
echo str_repeat('&nbsp;', 50); // adds 5 spaces;
?>

  <a href class="mail1" "mailto:hermeneutika@msn.com">My email feel free to contact me</a>

<br>
<?php include ("menu1.php"); ?>  
<br>
<br>
<p> This is my home page and very much under construction. Most of the researchers and politicians etc take hyper linked  </p>
<p>documentation systems for granted. It is a background skill to present whatever it is they are presenting. </p>
<p> A web site is a communication in the public domain. It is no longer a private opinion but a publically expressed opinion</p>
<p>A shared opinion is crucial to getting anything done. So called Science is about shared "opinions" and a reference to the "facts" ought to end all argument</p>

<video width="320" height="240" controls>
  <source src="video/me1.mp4" type="video/mp4">
  Your browser does not support the video tag.
</video> 

    
</body>
</html>