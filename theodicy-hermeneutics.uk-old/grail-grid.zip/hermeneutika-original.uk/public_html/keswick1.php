<!DOCTYPE html>
<html>
<head>
<style>
</style>
<link href="menu.css" rel="stylesheet" type="text/css" />
</head>
<body>

<?php include ("menu-main.php"); ?>
<a href ="https://vkc.keswickministries.org/day/?d=20210803" style="color:white">Main Keswick Conf site</a>

<h1>Keswick Conference</h1>
<h1>First main Christian meeting since lockdown</h1>



</body>
</html>