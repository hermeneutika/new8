<ul>
<li class="dropdown">
    <a href="index.php" class="dropbtn">Home</a>

    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">The Bible</a>
    <div class="dropdown-content">
      <a href="bible1.php">Bible search</a>
      <a href="#">What the Bible says</a>
      <a href="#">His critics</a>
    </div>
  </li>
<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Jesus the Christ</a>
    <div class="dropdown-content">
      <a href="#">Who is He?</a>
      <a href="#">What the Bible says</a>
      <a href="#">His critics</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Work</a>
    <div class="dropdown-content">
      <a href="#">the cv</a>
      <a href="#">Work ethic</a>
      <a href="#">philosopy of work</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Films</a>
    <div class="dropdown-content">
      <a href="#">Solaris</a>
      <a href="#">Jesus of Nazereth</a>
      <a href="#">2001</a>
      <a href="#">Dr Zhivargo</a>

    </div>
  </li>


<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">University</a>
    <div class="dropdown-content">
      <a href="#">Biblical hermeneutics</a>
      <a href="#">The philosophy of science</a>
      <a href="#">The philosophy of religion</a>
      <a href="#">Web Design</a>
      <a href="#">Database</a>
      <a href="#">PHP</a>
      <a href="epist1.php">Epistemology</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Great Courses</a>
    <div class="dropdown-content">
      <a href="#">Wisdom lit</a>
      <a href="#">republic of virtue</a>
      <a href="#">history of the Bible</a>
    </div>
  </li>


  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Books</a>
    <div class="dropdown-content">
      <a href="#">Songs of Zion</a>
      <a href="#">Commentary on Ezekiel</a>
      <a href="#">Bible</a>
      <a href="book-tech.php">Sitepoint</a>
      <a href="relation1.php">Relational databases</a>
    </div>
  </li>

  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Music</a>
    <div class="dropdown-content">
      <a href="#">John Michael Talbot</a>
      <a href="#">Hawkwind</a>
      <a href="#">Judas Priest</a>
      <a href="#">Psy Trance</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Video</a>
    <div class="dropdown-content">
      <a href="#">Music</a>
      <a href="video1.php">political and other</a>
      <a href="#">Tutorial</a>
    </div>
  </li>

  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Ecclesia</a>
    <div class="dropdown-content">
      <a href="#">What is Ecclesia</a>
      <a href="#">Local Church</a>
      <a href="#">Body of Christ</a>
      <a href="keswick1.php">Keswick Conference</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Drugs</a>
    <div class="dropdown-content">
      <a href="#">Heroin</a>
      <a href="#">LSD</a>
      <a href="#">Marijuana</a>
    </div>
  </li>

  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">the problem of evil</a>
    <div class="dropdown-content">
      <a href="#">theodicy</a>
      <a href="#">books</a>
      <a href="#">Thoughts</a>
    </div>
  </li>

  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Current events</a>
    <div class="dropdown-content">
      <a href="covid1.php">covid</a>
      <a href="#">brexit</a>
      <a href="#">statistics</a>
      <a href="#">Afghan</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">rt-pcr tests</a>
    <div class="dropdown-content">
      <a href="pcr-hist1.php">history</a>
      <a href="#">Certain knowledge</a>
      <a href="#">statistics</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Databases</a>
    <div class="dropdown-content">
      <a href="https://www.prdl.org/">Post Reformation Digital Library</a>
      <a href="https://www.prdl.org/digital_libraries.php">List of digital libraries</a>
      <a href="https://www.prdl.org/secondary.php?src_type=Theology&sec_limit=individual&sort=">More Databases</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">The ancient tree of knowledge</a>
    <div class="dropdown-content">
      <a href="text/philo&theo.pdf">History of the sciences</a>
      <a href="pcr-hist1.php">Greeks and Scholastics</a>
      <a href="#">Theology</a>
      <a href="#">Philosophy</a>
      <a href="#">The natural sciences</a>
    </div>
  </li>
</ul>
