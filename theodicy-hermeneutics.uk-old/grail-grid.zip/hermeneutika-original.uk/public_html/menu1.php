<body>
  <div class="container">
  <h3>hermeneutika's Home Pages</h3>

  <nav>
    <ul class="nav-menu nav-center">
      <li>
       
        <a href="#" class="nav-active">Bible</a>
        <ul>
          <li><a href="#">hermeneutics</a></li>
          <li>
            <a href="#">Scriptures</a>
            <ul>
              <li><a href="rev1.php">Revelation</a></li>
              <li><a href="#">Exekiel</a></li>
              <li><a href="#">Psalms</a></li>
            </ul>
          </li>
          <li><a href="#">Sermons</a></li>
          <li><a href="#">Doctrine and Dogma</a></li>
        </ul>
      </li>

      <li><a href="#" class="nav-active">Music</a>
      <ul>
      <li><a href="#">Electronic</a>

      <ul>
      <li><a href="#">blutengel</a></li>
      <li><a href="#">hawkwind</a></li>
      <li><a href="#">Psy Trance</a></li>
      
</ul>
</li>
<li><a href="#">Thrash</a>
<ul>
<li><a href="#">Vengeance Rising</a></li>
<li><a href="#">Deliverance</a></li>
</ul>
</li>
</ul>
</li>

      <li><a href="#" class="nav-active">Sciences</a>
        <ul>
          <li><a href="#">Great courses</a>
          <ul>
          <li><a href="#">building a republic of virtue</a></li>
          <li><a href="#">Philosophy of science</a></li>
</ul>
</li>
          <li>
            <a href="#">Open University</a>
            <ul>
              <li><a href="#">Web design</a></li>
              <li><a href="#">Networking</a></li>
              <li><a href="#">relational databases</a></li>
            </ul>
          </li>
          <li><a href="#">Udemy</a>
<ul>
<li><a href="#">html css</a></li>
</ul>
</li>

          <li><a href="#" class="nav-active">Biology</a>
          <ul>
            <li><a href="#">PCR testing</a></li>
            <li><a href="#">Evolution</a></li>
            <li><a href="#">DNA</a></li>
            <li><a href="#">Research</a></li>
</ul>
</li>
<li><a href="#" class="nav-active">Nuclear fusion</a>
<ul>
<li><a href="https://www.iter.org/">ITER</a></li>
</ul>
</li>
        </ul>
      </li>
      <li><a href="#">Misc</a></li>
      <li><a href="index.php">Home</a></li>
      <li><a href="#">Videos</a>
      <ul>
      <li><a href="purdom1.php">Dr Georgia Purdom The wonder of DNA</a></li>
</ul>


</li>
    </ul>
  </nav>