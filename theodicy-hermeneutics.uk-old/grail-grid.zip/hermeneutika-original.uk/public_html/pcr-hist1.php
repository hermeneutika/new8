<!DOCTYPE html>
<html>
<head>
<style>
</style>
<link href="menu.css" rel="stylesheet" type="text/css" />
</head>
<body>
<h1 style {color:black;}>The history and science of rt-pcr "testing"</h1>
<h1>True and certain knowledge</h1>
<?php include ("menu-main.php"); ?>

<a href="https://www.nobelprize.org/prizes/medicine/1960/burnet/biographical/"> Nobel prize winner</a>
<a href="https://www.youtube.com/watch?v=EWNkJUDctdk&t=927s">original video casting doubt on rt-pcr</a>
<a href="https://en.wikipedia.org/wiki/Kary_Mullis">the inventor of rt-pcr tests-Kary Mullis</a>
<P>I used to work in a foundry. I had to TEST the castings. As if the castings did not meet th required standards</p>
<p>They would not be of any use to the customer. eg we did castings for oil rigs.They had to meet the required standards. </p>
<p>t is a method using specific synthetic chemical linkers to divert an immune response from its nominal target to something completely different which you would right now like to be temporarily immune to. Let's say you just got exposed to a new strain of the flu. You're already immune to alpha-1,3-galactosyl-galactose bonds. All humans are. Why not divert a fraction of those antibodies to the influenza strain you just picked up? A chemical linker synthesized with an alpha-1,3-gal-gal bond on one end and a DNA aptamer devised to bind specifically to the strain of influenza you have on the other end will link anti-alpha-Gal antibodies to the influenza virus and presto!--you have fooled your immune system into attacking the new virus.[9][34](https://en.wikipedia.org/wiki/Kary_Mullis)</p>
<a href="https://en.wikipedia.org/wiki/Taq_polymerase">Taq polymerase....a lot here</p>

</body>
</html>
