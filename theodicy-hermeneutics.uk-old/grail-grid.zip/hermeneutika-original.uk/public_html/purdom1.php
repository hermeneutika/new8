<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="menu.css" />
  <link rel="stylesheet" href="header.css" />
  <link rel="stylesheet" href="site.css" />
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dr Georgia Purdom</title>
</head>
<body>
<?php include ("menu1.php"); ?> 

<div><p><?php include('purdom1.txt'); ?></p></div>

<video width="320" height="240" controls>
  <source src="video/purdom1.mp4" type="video/mp4">
  Your browser does not support the video tag.
</video> 




</body>
</html>