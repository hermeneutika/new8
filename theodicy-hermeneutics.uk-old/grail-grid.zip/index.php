<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <title>Title</title>
    <link rel="stylesheet" href="index.css">
  </head>
  <body>
    <div class="container">
      <div class="header"><?php include 'nav.php' ?>Header</div>
      <div class="panel left">
      <img src="palestine.jpg" width="160px" height="180px" alt="Palestinian Delusion cover image">
      <img src="myth1.jpeg" width="160px" height="180px" alt="mytho f mental illness image">


      </div>
      <div class="mainbody"><!--Main Body--> The Word of God is the total solution<br>
      Joh 3:3  Jesus answered and said unto him, Verily, verily, I say unto thee, Except a man be born again, he cannot see the kingdom of God.<br>
Joh 3:7  Marvel not that I said unto thee, Ye must be born again.<br>
1Pe 1:23  Being born again, not of corruptible seed, but of incorruptible, by the word of God, which liveth and abideth for ever.<br>


<img src ="philo-foundations.webp" width="160px" height="180px" alt="philosophical foundations">
      <!--
           Gen 2:17  But of the tree of the knowledge of good and evil, thou shalt not eat of it: for in the day that thou eatest thereof thou shalt surely die.<br>


           Gen 3:4  And the serpent said unto the woman, Ye shall not surely die:<br>

           17    And unto Adam he said, Because thou hast hearkened unto the voice of thy wife, and hast eaten of the tree, of which I commanded thee, saying, Thou shalt not eat of it: cursed [is] the ground for thy sake; in sorrow shalt thou eat [of] it all the days of thy life;<br>
18  Thorns also and thistles shall it bring forth to thee; and thou shalt eat the herb of the field;<br>
19  In the sweat of thy face shalt thou eat bread, till thou return unto the ground; for out of it wast thou taken: for dust thou [art], and unto dust shalt thou return.<br>
<br><br></div> -->

</div>
      <div class="panel right content">
      <img src="bible.jpg" width="160px" height="180px" alt="bible photo">
            <img src="interp1.jpg" width="160px" height="180px" alt="interpretation of the NT">
      </div>
      <div class="footer">Footer</div>
    </div>
  </body>
</html>