<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241024;8303320">
	<META NAME="CHANGED" CONTENT="20241024;8322377">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
		A:link { so-language: zxx }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Islam</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Here is a
debate between a prominent Christian and a prominent Muslim. </FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><A HREF="https://www.youtube.com/watch?v=PZYmb0BlqNY&amp;t=1359s">https://www.youtube.com/watch?v=PZYmb0BlqNY&amp;t=1359s</A></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>You pays
yer money and yers make your choice. </FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>