<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241214;10371134">
	<META NAME="CHANGED" CONTENT="20241214;11012032">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Israel/Palestine
</FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>When I was
a youth all the older ex national service men said to me that there
will never be peace in the Middle East. Looks like they were right.
That is correct. That was more that a opinion it was a correct
understanding of the Middle Eastern situation. </FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>So how is
the circle squared? If one is even to begin to understand the
situation in the Middle East(ME) the concept of God cannot be left
out. A secular analysis is just not sufficient or up to the task.
Surely then a understanding of Judaism,Christianity and Islam is also
required. And this must of necessity involve a understanding of the
hermeneutics of each faith. And then how is it even possible to
arrive at a &ldquo;true&rdquo; understanding of the conflict. </FONT>
</P>
</BODY>
</HTML>