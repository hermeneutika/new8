<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241022;14371578">
	<META NAME="CHANGED" CONTENT="20241022;21203166">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<P CLASS="western">&lt;?php include 'nav.php' ?&gt; 
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Jesus the
Christ</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Christ is
of course a title. Most people either dont know this or just think
its His surname! So in my opinion it is completely appropriate to
refer to Him as Jesus the Christ. Jesus the Anointed One or Jesus the
Messiah. </FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>So the
question of God Himself crops up. And certainly the Christian claim
is that Jesus is  God. </FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>