<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241025;14421509">
	<META NAME="CHANGED" CONTENT="20241025;14434326">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		A:link { so-language: zxx }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<p> testing</p>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>News</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5><A HREF="https://www.thetimes.com/article/adriana-brownlee-becomes-youngest-woman-to-conquer-the-14-peaks-t5kzjcdn5">https://www.thetimes.com/article/adriana-brownlee-becomes-youngest-woman-to-conquer-the-14-peaks-t5kzjcdn5</A></FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>The amazing achievement of
one so young. </FONT>
</P>
</BODY>
</HTML>