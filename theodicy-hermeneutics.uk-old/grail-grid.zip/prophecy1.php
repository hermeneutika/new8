<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241103;11262500">
	<META NAME="CHANGED" CONTENT="20241105;13281819">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=3 STYLE="font-size: 13pt"><B>Re
19:10</B></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">
 And I fell at his feet to worship him. And he said unto me, See </SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><I><SPAN STYLE="font-weight: normal">thou
do it</SPAN></I></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="font-weight: normal">
not: I am thy fellowservant, and of thy brethren that have the
testimony of Jesus: worship God: for the testimony of Jesus is the
</SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>spirit</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
of </SPAN></SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><U><B>prophecy</B></U></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">.</SPAN></SPAN></SPAN></FONT></FONT></FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; text-decoration: none">
<BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="text-decoration: none"><FONT FACE="Segoe UI, sans-serif">Either
the Bible is just a old book with no relevance for today or it is
indeed the very Word of God.</FONT></SPAN> </FONT></FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; text-decoration: none">
<BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt">Or
from Joseph Seiss in his excellent commentary on the Book of
Revelation. </FONT></FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; text-decoration: none">
<BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>But
no true Christian has any right to count on dying. There is</FONT></FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>something
that is more certain than death. There are some who will never</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>die.
Those who are alive and waiting for Christ when he comes, shall never</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=2><FONT SIZE=3>taste
of death. They shall be &ldquo;</FONT><FONT SIZE=3><I>taken</I></FONT><FONT SIZE=3>&rdquo;
as Enoch was taken, as Elijah was</FONT></FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>taken,
as Romanists allege that the Virgin Mary was taken, and as some</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>say
the Apostle John was taken. The words of Paul upon this point are too</FONT></FONT></P>
<P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>plain
to be misunderstood. He says, &ldquo;The Lord himself shall descend
from</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=3>heaven
with a shout,&hellip; and we which are alive and remain shall be
caught</FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=5>if
someone could reveal to  one, things that are shortly to take place,
ie soon. I think perhaps we would be interested. </FONT></FONT>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; text-decoration: none">
<BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; text-decoration: none">
<BR>
</P>
</BODY>
</HTML>