<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE>Document</TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="0;0">
	<META NAME="CHANGED" CONTENT="20241128;9175423">
	<META NAME="" CONTENT="">
	<META NAME="viewport" CONTENT="width=device-width, initial-scale=1.0">
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<P>&lt;?php include 'nav.php'; ?&gt; 
</P>
<P><BR><BR>
</P>
<P><FONT SIZE=5>Biblical prophecy. The Bible is not only a
instruction manual it is also a book of prophesy. If God be God then
He is capable of anything. I think we have a much too limited view of
Who the Almighty actually is! I think that God not only predicts the
future He actually creates it by His Word. This is the power of the
One True God. He has actually written down His prophesies. The whole
prophesy thing comes down to ones view of  what some might call the
&ldquo;Holy Scriptures&rdquo;.</FONT></P>
</BODY>
</HTML>