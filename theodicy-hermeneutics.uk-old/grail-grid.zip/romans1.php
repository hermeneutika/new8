<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241026;14020905">
	<META NAME="CHANGED" CONTENT="20241026;14102161">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
		A:link { so-language: zxx }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Romans</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Understandest
what thou readest??</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=3 STYLE="font-size: 13pt"><SPAN STYLE="font-weight: normal">30
</SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-weight: normal">
And Philip ran thither to </SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><I><SPAN STYLE="font-weight: normal">him</SPAN></I></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="font-weight: normal">,
and heard him read the prophet Esaias, and said, Understandest thou
what thou readest?</SPAN></SPAN></FONT></FONT></FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=3 STYLE="font-size: 13pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="font-weight: normal">31
</SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="font-weight: normal">
And he said, How can I, except some man should guide me? And he
desired Philip that he would come up and sit with him.</SPAN></SPAN></FONT></FONT></FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=5 STYLE="font-size: 20pt"><SPAN STYLE="font-style: normal"><SPAN STYLE="font-weight: normal">So
commentaries. </SPAN></SPAN></FONT></FONT></FONT>
</P>
</BODY>
</HTML>