<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241022;14181841">
	<META NAME="CHANGED" CONTENT="20241022;14330602">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php' ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Science
Fiction</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>I am now
aproximately 72 solar cycles of age.....I started with SF when I was
a teenager. Along with the Greek classics. (Oddysey and Iliad plus
Virgil's Anead.)I read a lot of Azimov and Heinlein. Heinlein
especially was a major influence in my life. Especially with stories
like &ldquo;The Green Hills of Earth&rdquo; and &ldquo;Starman Jones&rdquo;
and of course &ldquo;Skylift&rdquo;. The heroism,devotion to duty and
bravery of his characters I found compelling. </FONT>
</P>
</BODY>
</HTML>