<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241214;10483529">
	<META NAME="CHANGED" CONTENT="20241214;11011181">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		P.western { so-language: en-GB }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Christian
Teachers</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>Anyone
involved in learning and teaching has many issues to deal with.
Including the concept of good and bad teachers. And then of course
the problem of true and false teachers. This applies not just to
Christianity but really to any subject area. I tend to do computer
courses. Some teachers are (IMHO) excellent teachers and also
authentic(their code works) others not so good and full of themselves
and their codes doesnt work! And so to Christian teachers. It is the
responsibility of the student to seek out good and authentic
teachers. And of course the student can be decieved by wily false and
useless teachers. It would seem then that the student is responsible
for choosing his own teachers. And since scandal ,rightly or wrongly
can destroy a teachers legacy, eg Ravi Zacherias ,Mike Bickle et al
ad nauseum. Then perhaps it would be wise to choose teachers who are
dead and no scandal attached to them. They are perhaps beyond
reproach, unless a old scandal is unearthed. But so far the teachers
I mention have no scandal attached to their name and nobody knows of
any!</FONT></P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><BR>
</P>
<P CLASS="western" STYLE="margin-bottom: 0cm"><FONT SIZE=5>So if they
are morally ok then the second test kicks in.....are they true or
false teachers?  </FONT>
</P>
</BODY>
</HTML>