<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241028;17410554">
	<META NAME="CHANGED" CONTENT="20241028;18101248">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P STYLE="margin-bottom: 0cm">What is Theodicy?</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm">I am not too sure about Theodicy
outside of Christendom. But then Buddhism posits that all life is
suffering as one of its Noble Truths. But certainly Christianity has
to face the problem of a kind and loving and merciful God in the face
of extreme evil and suffering. Eg all the wars. 
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>