<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<head>

<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" href="css/index.css" />
<?php include 'nav.php'; ?>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241102;16352265">
	<META NAME="CHANGED" CONTENT="20241102;16580755">
	<STYLE TYPE="text/css">
	/*
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		A:link { so-language: zxx }
	-->
	*/
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
	
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>Tim Lambesis (written on 2
nov 24 after all the band quit but noone knows why!!)</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>The interesting case of
Tim Lambesis. At 72 years of age I may be too old and poor to rock
out as if I was 18! But that doesnt mean I have lost interest in the
genre of all things rock,thrash etc. I first got interested in AILD
round about 2007 with their acclaimed album &ldquo;A ocean between
us&rdquo; and especially the track &ldquo;Nothing left&rdquo; which
has special emotional and even spiritual  connotations for me. And
then came the bombshell of Tim Lambesis attempting to have his
estranged wife murdered by a &ldquo;hitman&rdquo;. The &ldquo;hitman&rdquo;
turned out to be a undercover FBI agent. So Tim was arrested,stood
trial and then sent to jail. I became quite interested in the case.
It looks like the estrangement and eventual divorce was Tim's own
fault? On the other hand it has been said that it always takes two to
tango??</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5><SPAN LANG="en">In August
2012, Lambesis sent an email to his wife, Meggan Murphy-Lambesis,
while on tour with As I Lay Dying in which he stated </SPAN><SPAN LANG="en"><B>he
no longer loved her, had engaged in an extramarital affair, and &quot;no
longer believed in God&quot;</B></SPAN><SPAN LANG="en">. They
separated the same month.</SPAN></FONT></P>
<P STYLE="margin-bottom: 0cm"> 
<FONT SIZE=5>(<A HREF="https://www.google.com/search?client=firefox-b-d&amp;q=why+was+lambesis+estranged+from+his+wife">https://www.google.com/search?client=firefox-b-d&amp;q=why+was+lambesis+estranged+from+his+wife</A>)</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>I guess if you have never
been divorced you may not fully understand the full range of
emotions. Even though apparently he was the guilty party he did
things which he ought not to have done. Up to and including
attempting to hire a &ldquo;hitman&rdquo;. </FONT>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>I know when I went through
a seperation I was wishing harm on my ex and her new partner. I still
think Tim was enticed into the act, when he was emotionally
disturbed. </FONT>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>So he did the jail time.
Gets out. Issues the apologies which I think were sincere, but of
course others were cynical and would not accept the apology. </FONT>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>