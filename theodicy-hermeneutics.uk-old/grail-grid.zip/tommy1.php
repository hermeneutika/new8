<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241028;20532611">
	<META NAME="CHANGED" CONTENT="20241028;21055539">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>Tommy Robinson</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>According to todays &ldquo;news&rdquo;
Mr Robinson has been sent to prison for just under 18 months for
&ldquo;contempt of court&rdquo;. And according to the &ldquo;news&rdquo;
outlets Mr Robinson has actually admitted that he was indeed in
contempt of court. Now if one believes in the rule of law, and there
is a offence called contempt of court, and Mr Robinson has pleaded
guilty, then what is the problem? Am I missing something? I happen to
like Mr Stephen Yaxley-Lennon(aka Mr Tommy Robinson) but if even he
admits he was in the wrong by publicly showing the film &ldquo;Silenced&rdquo;
when the showing of this film would place him in contempt, then what
is going on? </FONT>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5>It seems almost as if Mr
Robinson wants to go to prison. He ought not to have gotten involved
with the Syrian refugee. He should have stuck to his critique of
Islam and the problems of the grooming gangs. </FONT>
</P>
</BODY>
</HTML>