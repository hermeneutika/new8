<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241103;7343917">
	<META NAME="CHANGED" CONTENT="20241103;7401833">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?>
<P STYLE="margin-bottom: 0cm">The vexed question of non violence</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm">What ought the Christians response be
to violent aggression? Eg world war two and the death of the Jews. Or
Israel after Oct 7<SUP>th</SUP>. Surely some violence is so egregious
that the only response is lethal violence?</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=4 STYLE="font-size: 16pt"><SPAN STYLE="font-weight: normal">Ro
13:4</SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=6><SPAN STYLE="font-weight: normal">
 For he is the minister of God to thee for good. But if thou do that
which is evil, be afraid; for he beareth not the </SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=6><U><B>sword</B></U></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=6><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
in </SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=6><U><B>vain</B></U></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=6><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">:
for he is the minister of God, a revenger to </SPAN></SPAN></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=6><I><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">execute</SPAN></SPAN></I></FONT></FONT></FONT><FONT COLOR="#000000"><FONT FACE="Segoe UI, sans-serif"><FONT SIZE=6><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">
wrath upon him that doeth evil.</SPAN></SPAN></SPAN></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT FACE="Times New Roman, serif"><FONT SIZE=5><FONT COLOR="#000000"><SPAN STYLE="font-style: normal"><SPAN STYLE="text-decoration: none"><SPAN STYLE="font-weight: normal">Here
is the verse that seems to legitimise violence by the State. </SPAN></SPAN></SPAN></FONT></FONT></FONT>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>