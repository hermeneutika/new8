<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=windows-1252">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="OpenOffice 4.1.15  (Win32)">
	<META NAME="CREATED" CONTENT="20241021;21292276">
	<META NAME="CHANGED" CONTENT="20241105;13483070">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
		A:link { so-language: zxx }
	-->
	</STYLE>
</HEAD>
<BODY LANG="en-GB" DIR="LTR">
<?php include 'nav.php'; ?> 
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5 STYLE="font-size: 20pt">The
Word of God and women. </FONT>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5 STYLE="font-size: 20pt">Here
is a challenging link, written by a woman(who is of course biased! As
am I!)</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><A HREF="https://simplychurch.com/a-simple-guide-to-the-challenging-scriptures-for-women/"><FONT SIZE=5 STYLE="font-size: 20pt">https://simplychurch.com/a-simple-guide-to-the-challenging-scriptures-for-women/</FONT></A></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5 STYLE="font-size: 20pt">More
links on females....</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5 STYLE="font-size: 20pt"><B>Margaret
Elaine Hamilton</B></FONT> <FONT SIZE=5 STYLE="font-size: 20pt">(<A HREF="https://en.wikipedia.org/wiki/Birth_name#Maiden_and_married_names">n&eacute;e</A>&nbsp;</FONT><FONT SIZE=5 STYLE="font-size: 20pt"><B>Heafield</B></FONT><FONT SIZE=5 STYLE="font-size: 20pt">;
born August 17, 1936) is an American <A HREF="https://en.wikipedia.org/wiki/Computer_scientist">computer
scientist</A>. She was director of the Software Engineering Division
of the <A HREF="https://en.wikipedia.org/wiki/Draper_Laboratory">MIT
Instrumentation Laboratory</A>, which developed on-board flight
software for <A HREF="https://en.wikipedia.org/wiki/NASA">NASA</A>'s
<A HREF="https://en.wikipedia.org/wiki/Apollo_program">Apollo
program</A>. She later founded two software companies&mdash;Higher
Order Software in 1976 and Hamilton Technologies in 1986, both in
<A HREF="https://en.wikipedia.org/wiki/Cambridge,_Massachusetts">Cambridge,
Massachusetts</A>. </FONT>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><A NAME="cite_ref-1"></A><FONT SIZE=5 STYLE="font-size: 20pt"><B>Grace
Brewster Hopper</B></FONT> <FONT SIZE=5 STYLE="font-size: 20pt">(<A HREF="https://en.wikipedia.org/wiki/Birth_name#Maiden_and_married_names">n&eacute;e</A>&nbsp;</FONT><FONT SIZE=5 STYLE="font-size: 20pt"><B>Murray</B></FONT><FONT SIZE=5 STYLE="font-size: 20pt">;
December 9, 1906 &ndash; January 1, 1992) was an American <A HREF="https://en.wikipedia.org/wiki/Computer_scientist">computer
scientist</A>, <A HREF="https://en.wikipedia.org/wiki/Mathematician">mathematician</A>,
and <A HREF="https://en.wikipedia.org/wiki/United_States_Navy">United
States Navy</A> <A HREF="https://en.wikipedia.org/wiki/Rear_admiral_(United_States)">rear
admiral</A>.<A HREF="https://en.wikipedia.org/wiki/Grace_Hopper#cite_note-1">[1]</A>
She was a pioneer of computer programming. Hopper was the first to
devise the theory of machine-independent programming languages, and
used this theory to develop the <A HREF="https://en.wikipedia.org/wiki/FLOW-MATIC">FLOW-MATIC</A>
programming language and <A HREF="https://en.wikipedia.org/wiki/COBOL">COBOL</A>,
an early <A HREF="https://en.wikipedia.org/wiki/High-level_programming_language">high-level
programming language</A> still in use today. She was also one of the
first programmers on the <A HREF="https://en.wikipedia.org/wiki/Harvard_Mark_I">Harvard
Mark I</A> computer. She is credited with writing the first computer
manual, &quot;A Manual of Operation for the Automatic </FONT>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><A NAME="cite_ref-AnnRev_1-0"></A><FONT SIZE=5 STYLE="font-size: 20pt"><B>Nancy
Grace Roman</B></FONT> <FONT SIZE=5 STYLE="font-size: 20pt">(May 16,
1925 &ndash; December 25, 2018) was an American astronomer who made
important contributions to <A HREF="https://en.wikipedia.org/wiki/Stellar_classification">stellar
classification</A> and motions. The first female executive at <A HREF="https://en.wikipedia.org/wiki/NASA">NASA</A>,
Roman served as NASA's first Chief of Astronomy throughout the 1960s
and 1970s, establishing her as one of the &quot;visionary founders of
the US civilian space program&quot;.<A HREF="https://en.wikipedia.org/wiki/Nancy_Roman#cite_note-AnnRev-1">[1]</A>
</FONT>
</P>
<P><A NAME="cite_ref-NPRObit_2-0"></A>Roman created NASA's space
astronomy program and is known to many as the &quot;Mother of Hubble&quot;
for her foundational role in planning the <A HREF="https://en.wikipedia.org/wiki/Hubble_Space_Telescope">Hubble
Space Telescope</A>.<A HREF="https://en.wikipedia.org/wiki/Nancy_Roman#cite_note-NPRObit-2">[2]</A>
Throughout her career, Roman was an active public speaker and
educator, and an advocate for <A HREF="https://en.wikipedia.org/wiki/Women_in_science">women
in the sciences</A>. 
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
<P STYLE="margin-bottom: 0cm"><FONT SIZE=5 STYLE="font-size: 20pt">Hedy
Lamarr commonly regarded as a extremely beautiful woman.</FONT></P>
<P LANG="en" STYLE="margin-bottom: 0cm"><FONT SIZE=5 STYLE="font-size: 20pt"><B>Hedy
Lamarr</B> was an Austrian-American actress and inventor who
pioneered the technology that would one day form the basis for
today's WiFi, GPS, and Bluetooth communication systems.</FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>